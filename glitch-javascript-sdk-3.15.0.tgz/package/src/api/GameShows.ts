import GameShowsRoute from "../routes/GameShowsRoute";
import Requests from "../util/Requests";
import Response from "../util/Response";
import { AxiosPromise } from "axios";

export interface GameShowScheduleTicketTypeInput {
    name: string;
    description?: string | null;
    kind: 'early_bird' | 'regular' | 'other';
    price_cents: number;
    currency: string;
    quantity_available?: number | null;
    sales_start_at?: string | null;
    sales_end_at?: string | null;
    sort_order?: number;
    is_active?: boolean;
}

export interface GameShowFestivalTicketTypeInput extends GameShowScheduleTicketTypeInput {
    scope: 'session' | 'festival' | 'track' | 'bundle';
    schedule_item_id?: string | null;
    track_block_id?: string | null;
    schedule_item_ids?: string[] | null;
}

export interface GameShowScheduleTicketPurchaseInput {
    ticket_type_id: string;
    email: string;
    first_name?: string;
    last_name?: string;
    quantity: number;
    payment_method_id?: string;
}

export interface GameShowScheduleTicketRefundInput {
    amount_cents: number;
    reason?: string;
}

export interface GameShowTitleCandidate {
    id: string;
    name: string;
    developer?: string | null;
    publisher?: string | null;
    short_description?: string | null;
    image_main?: string | null;
    image_banner?: string | null;
    is_live: boolean;
    already_in_showcase: boolean;
    community?: { id: string; name: string } | null;
}

export interface GameShowTitleCandidateSearchParams {
    q: string;
    page?: number;
    per_page?: number;
}

class GameShows {

    /**
     * List all the GameShows.
     * 
     * @see https://api.glitch.fun/api/documentation#/GameShows/getGameShows
     * 
     * @returns promise
     */
    public static list<T>(params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.list, undefined, undefined, params);
    }

    /**
     * Create a new game show.
     * 
     * @see https://api.glitch.fun/api/documentation#/GameShows/createGameShow
     * 
     * @param data The data to be passed when creating a game show.
     * 
     * @returns Promise
     */
    public static create<T>(data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {

        return Requests.processRoute(GameShowsRoute.routes.create, data, undefined, params);
    }

    /**
     * Update a game show.
     * 
     * @see https://api.glitch.fun/api/documentation#/GameShows/updateGameShow
     * 
     * @param show_id The id of the game show to update.
     * @param data The data to update.
     * 
     * @returns promise
     */
    public static update<T>(show_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {

        return Requests.processRoute(GameShowsRoute.routes.update, data, { show_id: show_id }, params);
    }

    /**
     * Retrieve the information for a single game show.
     * 
     * @see https://api.glitch.fun/api/documentation#/GameShows/getGameShowByUuid
     * 
     * @param show_id The id fo the game show to retrieve.
     * 
     * @returns promise
     */
    public static view<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {

        return Requests.processRoute(GameShowsRoute.routes.view, {}, { show_id: show_id }, params);
    }

    /**
     * Deletes a game show.
     * 
     * @see https://api.glitch.fun/api/documentation#/GameShows/deleteGameShow
     * 
     * @param show_id The id of the game show to delete.
     * @returns promise
     */
    public static delete<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {

        return Requests.processRoute(GameShowsRoute.routes.delete, {}, { show_id: show_id }, params);
    }

    /**
       * Updates the main image for the game show using a File object.
       * 
       * @see https://api.glitch.fun/api/documentation#/GameShows/uploadGameShowLogo
       * 
       * @param file The file object to upload.
       * @param data Any additional data to pass along to the upload.
       * 
       * @returns promise
       */
    public static uploadLogoFile<T>(show_id: string, file: File, data?: object, params?: Record<string, any>): AxiosPromise<Response<T>> {

        let url = GameShowsRoute.routes.uploadLogo.url.replace('{show_id}', show_id);

        return Requests.uploadFile(url, 'image', file, data);
    }

    /**
     * Updates the main image for the game show using a Blob.
     * 
     * @see https://api.glitch.fun/api/documentation#/GameShows/uploadGameShowLogo
     * 
     * @param blob The blob to upload.
     * @param data Any additional data to pass along to the upload
     * 
     * @returns promise
     */
    public static uploadLogoBlob<T>(show_id: string, blob: Blob, data?: object, params?: Record<string, any>): AxiosPromise<Response<T>> {

        let url = GameShowsRoute.routes.uploadLogo.url.replace('{show_id}', show_id);

        return Requests.uploadBlob(url, 'image', blob, data);
    }

    /**
     * Updates the banner image for the game show using a File object.
     * 
     * @see https://api.glitch.fun/api/documentation#/GameShows/uploadGameShowBannerImage
     * 
     * @param file The file object to upload.
     * @param data Any additional data to pass along to the upload.
     * 
     * @returns promise
     */
    public static uploadBannerImageFile<T>(show_id: string, file: File, data?: object, params?: Record<string, any>): AxiosPromise<Response<T>> {

        let url = GameShowsRoute.routes.uploadBannerImage.url.replace('{show_id}', show_id);

        return Requests.uploadFile(url, 'image', file, data);
    }

    /**
     * Updates the banner image for the game show using a Blob.
     * 
     * @see https://api.glitch.fun/api/documentation#/GameShows/uploadGameShowBannerImage
     * 
     * @param blob The blob to upload.
     * @param data Any additional data to pass along to the upload
     * 
     * @returns promise
     */
    public static uploadBannerImageBlob<T>(show_id: string, blob: Blob, data?: object, params?: Record<string, any>): AxiosPromise<Response<T>> {

        let url = GameShowsRoute.routes.uploadBannerImage.url.replace('{show_id}', show_id);

        return Requests.uploadBlob(url, 'image', blob, data);
    }

    /**
     * Register a title to a game show.
     */
    public static registerTitle<T>(show_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.registerTitle, data, { show_id: show_id }, params);
    }

    /** List the active ordered custom-question schema used by public registration. */
    public static listRegistrationQuestions<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listRegistrationQuestions, {}, { show_id: show_id }, params);
    }

    /** List active, inactive, and archived custom questions for organizers. */
    public static manageRegistrationQuestions<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.manageRegistrationQuestions, {}, { show_id: show_id }, params);
    }

    /** Create one schema-driven custom developer-registration question. */
    public static createRegistrationQuestion<T>(show_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.createRegistrationQuestion, data, { show_id: show_id }, params);
    }

    /** Update wording, validation, visibility, ordering, or stable choices. */
    public static updateRegistrationQuestion<T>(show_id: string, question_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.updateRegistrationQuestion, data, { show_id: show_id, question_id: question_id }, params);
    }

    /** Archive a question while preserving historical answers and reporting. */
    public static deleteRegistrationQuestion<T>(show_id: string, question_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.deleteRegistrationQuestion, {}, { show_id: show_id, question_id: question_id }, params);
    }

    /** Apply the organizer's exact ordered list of question UUIDs. */
    public static reorderRegistrationQuestions<T>(show_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.reorderRegistrationQuestions, data, { show_id: show_id }, params);
    }

    /** Review custom answers grouped by submitted game. */
    public static listRegistrationResponses<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listRegistrationResponses, {}, { show_id: show_id }, params);
    }

    /** Retrieve type-aware aggregate reports without exposing free-text values. */
    public static registrationQuestionReports<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.registrationQuestionReports, {}, { show_id: show_id }, params);
    }

    /**
     * Add a title to a game show by admin.
     */
    public static addTitle<T>(show_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.addTitle, data, { show_id: show_id }, params);
    }

    /** Search privacy-safe registered Glitch games that an organizer may attach to a festival. */
    public static searchTitleCandidates<T>(show_id: string, params: GameShowTitleCandidateSearchParams): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.searchTitleCandidates, {}, { show_id: show_id }, params);
    }

    /** Preview CSV/TSV/TXT/ZIP registrations without writing showcase data. */
    public static previewExternalTitles<T>(show_id: string, file: File, data?: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        // Multipart helpers require the concrete URL before uploading.
        const url = GameShowsRoute.routes.previewExternalTitles.url.replace('{show_id}', show_id);
        return Requests.uploadFile(url, 'file', file, data, params);
    }

    /** Import valid external registrations after organizer preview. */
    public static importExternalTitles<T>(show_id: string, file: File, data?: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        const url = GameShowsRoute.routes.importExternalTitles.url.replace('{show_id}', show_id);
        return Requests.uploadFile(url, 'file', file, data, params);
    }

    /**
     * List all titles for a game show.
     */
    public static listTitles<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listTitles, {}, { show_id: show_id }, params);
    }

    /**
     * Get details of a specific title in a game show.
     */
    public static getTitle<T>(show_id: string, title_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.viewTitle, {}, { show_id: show_id, title_id: title_id }, params);
    }

    /**
     * Update a specific title in a game show.
     */
    public static updateTitle<T>(show_id: string, title_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.updateTitle, data, { show_id: show_id, title_id: title_id }, params);
    }

    /**
     * Delete a specific title from a game show.
     */
    public static deleteTitle<T>(show_id: string, title_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.deleteTitle, {}, { show_id: show_id, title_id: title_id }, params);
    }

    /**
     * List public page-builder blocks for a game show.
     */
    public static listBlocks<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listBlocks, {}, { show_id: show_id }, params);
    }

    /** Paginate one Page Builder game section without downloading its full catalog. */
    public static listBlockTitles<T>(show_id: string, block_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listBlockTitles, {}, { show_id, block_id }, params);
    }

    /**
     * Create a page-builder block for a game show. Requires organizer permissions.
     */
    public static createBlock<T>(show_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.createBlock, data, { show_id: show_id }, params);
    }

    /**
     * Update a page-builder block for a game show. Requires organizer permissions.
     */
    public static updateBlock<T>(show_id: string, block_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.updateBlock, data, { show_id: show_id, block_id: block_id }, params);
    }

    /**
     * Delete a page-builder block from a game show. Requires organizer permissions.
     */
    public static deleteBlock<T>(show_id: string, block_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.deleteBlock, {}, { show_id: show_id, block_id: block_id }, params);
    }

    /**
     * Reorder page-builder blocks for a game show. Requires organizer permissions.
     */
    public static reorderBlocks<T>(show_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.reorderBlocks, data, { show_id: show_id }, params);
    }

    /**
     * List livestream and programming schedule items for a game show.
     */
    public static listSchedule<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listSchedule, {}, { show_id: show_id }, params);
    }

    /** Fetch one public or organizer-visible festival schedule item. */
    public static getScheduleItem<T>(show_id: string, schedule_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.getScheduleItem, {}, { show_id: show_id, schedule_id: schedule_id }, params);
    }

    /**
     * Create a schedule item for a game show. Requires organizer permissions.
     */
    public static createScheduleItem<T>(show_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.createScheduleItem, data, { show_id: show_id }, params);
    }

    /**
     * Update a schedule item for a game show. Requires organizer permissions.
     */
    public static updateScheduleItem<T>(show_id: string, schedule_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.updateScheduleItem, data, { show_id: show_id, schedule_id: schedule_id }, params);
    }

    /**
     * Delete a schedule item from a game show. Requires organizer permissions.
     */
    public static deleteScheduleItem<T>(show_id: string, schedule_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.deleteScheduleItem, {}, { show_id: show_id, schedule_id: schedule_id }, params);
    }

    /** List public festival, track, bundle, and single-session ticket products. */
    public static listFestivalTicketTypes<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listFestivalTicketTypes, {}, { show_id }, params);
    }

    /** List all festival ticket products, including archived products, for organizers. */
    public static manageFestivalTicketTypes<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.manageFestivalTicketTypes, {}, { show_id }, params);
    }

    /** Create a whole-festival pass, track pass, event bundle, or session ticket. */
    public static createFestivalTicketType<T>(show_id: string, data: GameShowFestivalTicketTypeInput, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.createFestivalTicketType, data, { show_id }, params);
    }

    /** Update the coverage, price, inventory, sales window, or visibility of a festival ticket product. */
    public static updateFestivalTicketType<T>(show_id: string, ticket_type_id: string, data: Partial<GameShowFestivalTicketTypeInput>, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.updateFestivalTicketType, data, { show_id, ticket_type_id }, params);
    }

    /** Archive a festival ticket product while retaining purchase history. */
    public static deleteFestivalTicketType<T>(show_id: string, ticket_type_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.deleteFestivalTicketType, {}, { show_id, ticket_type_id }, params);
    }

    /** Reserve inventory and create or confirm a festival-level ticket payment. */
    public static purchaseFestivalTickets<T>(show_id: string, data: GameShowScheduleTicketPurchaseInput, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.purchaseFestivalTickets, data, { show_id }, params);
    }

    /** Synchronize a festival-level ticket purchase after Stripe.js completes 3DS. */
    public static confirmFestivalTicketPurchase<T>(show_id: string, purchase_id: string, access_token: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.confirmFestivalTicketPurchase, { access_token }, { show_id, purchase_id }, params);
    }

    /** Retrieve a token-protected receipt for any festival ticket scope. */
    public static getFestivalTicketReceipt<T>(show_id: string, purchase_id: string, access_token: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.getFestivalTicketReceipt, {}, { show_id, purchase_id }, { ...params, access_token });
    }

    /** List purchasers across festival, track, bundle, and session ticket products. */
    public static listFestivalTicketPurchases<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listFestivalTicketPurchases, {}, { show_id }, params);
    }

    /** Issue a partial or full refund for a festival ticket purchase. */
    public static refundFestivalTicketPurchase<T>(show_id: string, purchase_id: string, data: GameShowScheduleTicketRefundInput, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.refundFestivalTicketPurchase, data, { show_id, purchase_id }, params);
    }

    /** List public early-bird, regular, and other ticket tiers for one session. */
    public static listScheduleTicketTypes<T>(show_id: string, schedule_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listScheduleTicketTypes, {}, { show_id, schedule_id }, params);
    }

    /** List every ticket tier, including archived tiers, for festival organizers. */
    public static manageScheduleTicketTypes<T>(show_id: string, schedule_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.manageScheduleTicketTypes, {}, { show_id, schedule_id }, params);
    }

    /** Create one session ticket price tier. */
    public static createScheduleTicketType<T>(show_id: string, schedule_id: string, data: GameShowScheduleTicketTypeInput, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.createScheduleTicketType, data, { show_id, schedule_id }, params);
    }

    /** Update ticket price, inventory, availability window, or publication state. */
    public static updateScheduleTicketType<T>(show_id: string, schedule_id: string, ticket_type_id: string, data: Partial<GameShowScheduleTicketTypeInput>, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.updateScheduleTicketType, data, { show_id, schedule_id, ticket_type_id }, params);
    }

    /** Archive a ticket tier while retaining historical purchases. */
    public static deleteScheduleTicketType<T>(show_id: string, schedule_id: string, ticket_type_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.deleteScheduleTicketType, {}, { show_id, schedule_id, ticket_type_id }, params);
    }

    /** Reserve inventory and create/confirm the session ticket PaymentIntent. */
    public static purchaseScheduleTickets<T>(show_id: string, schedule_id: string, data: GameShowScheduleTicketPurchaseInput, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.purchaseScheduleTickets, data, { show_id, schedule_id }, params);
    }

    /** Synchronize the same ticket PaymentIntent after Stripe.js completes 3DS. */
    public static confirmScheduleTicketPurchase<T>(show_id: string, schedule_id: string, purchase_id: string, access_token: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.confirmScheduleTicketPurchase, { access_token }, { show_id, schedule_id, purchase_id }, params);
    }

    /** Retrieve a token-protected customer receipt. */
    public static getScheduleTicketReceipt<T>(show_id: string, schedule_id: string, purchase_id: string, access_token: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.getScheduleTicketReceipt, {}, { show_id, schedule_id, purchase_id }, { ...params, access_token });
    }

    /** List ticket purchasers and refund state for festival organizers. */
    public static listScheduleTicketPurchases<T>(show_id: string, schedule_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listScheduleTicketPurchases, {}, { show_id, schedule_id }, params);
    }

    /** Issue a partial or full destination-charge refund at organizer discretion. */
    public static refundScheduleTicketPurchase<T>(show_id: string, schedule_id: string, purchase_id: string, data: GameShowScheduleTicketRefundInput, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.refundScheduleTicketPurchase, data, { show_id, schedule_id, purchase_id }, params);
    }

    /**
     * Get the game show discovery queue.
     */
    public static discoveryQueue<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.discoveryQueue, {}, { show_id: show_id }, params);
    }

    /**
     * Track public game show analytics events.
     */
    public static trackAnalytics<T>(show_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.trackAnalytics, data, { show_id: show_id }, params);
    }

    /**
     * Get organizer analytics for a game show.
     */
    public static analyticsReport<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.analyticsReport, {}, { show_id: show_id }, params);
    }

    /**
     * Join or update a public notification signup for a game show.
     */
    public static joinWishlist<T>(show_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.joinWishlist, data, { show_id: show_id }, params);
    }

    /**
     * Confirm the double-opt-in token from a festival reminder email.
     * The response contains confirmation state and festival identity only.
     *
     * @see https://api.glitch.fun/api/documentation#/GameShows/confirmGameShowWishlist
     */
    public static confirmWishlist<T>(token: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.confirmWishlist, {}, { token }, params);
    }

    /**
     * List notification signups for a game show. Requires organizer permissions.
     */
    public static listWishlist<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listWishlist, {}, { show_id: show_id }, params);
    }

    /** List the anonymous, published festival award/prize/swag catalog. */
    public static listPublicRewards<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listPublicRewards, {}, { show_id }, params);
    }

    /** Retrieve one SSR-ready public festival reward. */
    public static getPublicReward<T>(show_id: string, reward_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.getPublicReward, {}, { show_id, reward_id }, params);
    }

    /** Retrieve a privacy-safe public game leaderboard for one reward. */
    public static getPublicRewardLeaderboard<T>(show_id: string, reward_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.getPublicRewardLeaderboard, {}, { show_id, reward_id }, params);
    }

    /** List drafts, sponsor items, inventory, recipients, and fulfillment for organizers. */
    public static manageRewards<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.manageRewards, {}, { show_id }, params);
    }

    /** Claim an eligible attendee, entrant, points, or previously awarded festival reward. */
    public static claimReward<T>(show_id: string, reward_id: string, data: { title_id?: string } = {}, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.claimReward, data, { show_id, reward_id }, params);
    }

    /** Create an organizer-controlled festival award, prize, swag item, or reward. */
    public static createReward<T>(show_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.createReward, data, { show_id }, params);
    }

    /** Update publication, eligibility, metrics, inventory, or rich content. */
    public static updateReward<T>(show_id: string, reward_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.updateReward, data, { show_id, reward_id }, params);
    }

    /** Soft-delete one festival reward. */
    public static deleteReward<T>(show_id: string, reward_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.deleteReward, {}, { show_id, reward_id }, params);
    }

    /** Preview the organizer-only game or attendee performance leaderboard. */
    public static rewardLeaderboard<T>(show_id: string, reward_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.rewardLeaderboard, {}, { show_id, reward_id }, params);
    }

    /** Snapshot current metric leaders as reward recipients. */
    public static autoAwardReward<T>(show_id: string, reward_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.autoAwardReward, {}, { show_id, reward_id }, params);
    }

    /** Add a manual nominee, winner, honoree, claimant, or fulfillment record. */
    public static addRewardRecipient<T>(show_id: string, reward_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.addRewardRecipient, data, { show_id, reward_id }, params);
    }

    /** Update judging, claim, revocation, rank, or fulfillment state. */
    public static updateRewardRecipient<T>(show_id: string, reward_id: string, recipient_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.updateRewardRecipient, data, { show_id, reward_id, recipient_id }, params);
    }

    /**
     * List public game shows that include a title. Useful for game-page festival banners.
     */
    public static listForTitle<T>(title_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listForTitle, {}, { title_id: title_id }, params);
    }

    /** List organizer-visible developer claim and completion workflows. */
    public static listTitleClaims<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listTitleClaims, {}, { show_id }, params);
    }

    /** Invite or remind a developer to claim and complete a festival game. */
    public static inviteTitleClaim<T>(show_id: string, title_id: string, data: { email: string }, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.inviteTitleClaim, data, { show_id, title_id }, params);
    }

    /** Open a private festival game claim before authentication. */
    public static viewTitleClaim<T>(show_id: string, token: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.viewTitleClaim, {}, { show_id, token }, params);
    }

    /** Bind the invited game to the current user and one administered business. */
    public static claimTitle<T>(show_id: string, token: string, data: { community_id: string }, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.claimTitle, data, { show_id, token }, params);
    }

    /** Finish required game information and record the optional build choice. */
    public static completeTitleClaim<T>(show_id: string, token: string, data: { build_choice: 'upload' | 'skip'; build_completed?: boolean }, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.completeTitleClaim, data, { show_id, token }, params);
    }

    /** List private sponsor workflow, contact, billing, media, and placements. */
    public static listSponsors<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listSponsors, {}, { show_id }, params);
    }

    /** Create a manual sponsor or send a self-service invitation. */
    public static createSponsor<T>(show_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.createSponsor, data, { show_id }, params);
    }

    /** Retrieve one organizer-authorized festival sponsor. */
    public static getSponsor<T>(show_id: string, sponsor_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.getSponsor, {}, { show_id, sponsor_id }, params);
    }

    /** Update sponsor workflow, creative metadata, schedule, or billing terms. */
    public static updateSponsor<T>(show_id: string, sponsor_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.updateSponsor, data, { show_id, sponsor_id }, params);
    }

    /** Delete an unpaid sponsor and its placements. */
    public static deleteSponsor<T>(show_id: string, sponsor_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.deleteSponsor, {}, { show_id, sponsor_id }, params);
    }

    /** Replace the private token and resend the sponsor invitation. */
    public static resendSponsorInvitation<T>(show_id: string, sponsor_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.resendSponsorInvitation, {}, { show_id, sponsor_id }, params);
    }

    /** Add another festival, game, session, or event placement. */
    public static createSponsorPlacement<T>(show_id: string, sponsor_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.createSponsorPlacement, data, { show_id, sponsor_id }, params);
    }

    /** Partially update an existing sponsor placement. */
    public static updateSponsorPlacement<T>(show_id: string, sponsor_id: string, placement_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.updateSponsorPlacement, data, { show_id, sponsor_id, placement_id }, params);
    }

    /** Delete one placement without deleting the sponsor creative. */
    public static deleteSponsorPlacement<T>(show_id: string, sponsor_id: string, placement_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.deleteSponsorPlacement, {}, { show_id, sponsor_id, placement_id }, params);
    }

    /** List privacy-limited, publicly eligible creatives and placements. */
    public static listPublicSponsors<T>(show_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.listPublicSponsors, {}, { show_id }, params);
    }

    /** Open a token-protected sponsor portal without a user session. */
    public static sponsorInvitation<T>(token: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.sponsorInvitation, {}, { token }, params);
    }

    /** Upload sponsor image/video through the shared Media pipeline. */
    public static uploadSponsorInvitationMedia<T>(token: string, file: File, data?: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        // Sponsor uploads use the `media` multipart field documented by API.
        const url = GameShowsRoute.routes.sponsorInvitationUpload.url.replace('{token}', token);
        return Requests.uploadFile(url, 'media', file, data, params);
    }

    /** Submit sponsor identity, destination, and accessibility metadata. */
    public static submitSponsorInvitation<T>(token: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.sponsorInvitationSubmit, data, { token }, params);
    }

    /** Create/confirm a destination PaymentIntent from a PaymentMethod ID. */
    public static paySponsorInvitation<T>(token: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.sponsorInvitationPayment, data, { token }, params);
    }

    /** Synchronize the same intent after Stripe.js completes required 3DS. */
    public static confirmSponsorInvitationPayment<T>(token: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.sponsorInvitationConfirmPayment, {}, { token }, params);
    }

    /** List awards, prizes, and swag owned by a sponsor invitation. */
    public static sponsorInvitationRewards<T>(token: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.sponsorInvitationRewards, {}, { token }, params);
    }

    /** Create a draft sponsor-owned award, prize, or swag item. */
    public static createSponsorInvitationReward<T>(token: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.sponsorInvitationCreateReward, data, { token }, params);
    }

    /** Update sponsor-owned reward content and eligibility. */
    public static updateSponsorInvitationReward<T>(token: string, reward_id: string, data: object, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.sponsorInvitationUpdateReward, data, { token, reward_id }, params);
    }

    /** Remove a sponsor-owned draft reward. */
    public static deleteSponsorInvitationReward<T>(token: string, reward_id: string, params?: Record<string, any>): AxiosPromise<Response<T>> {
        return Requests.processRoute(GameShowsRoute.routes.sponsorInvitationDeleteReward, {}, { token, reward_id }, params);
    }

}

export default GameShows;
