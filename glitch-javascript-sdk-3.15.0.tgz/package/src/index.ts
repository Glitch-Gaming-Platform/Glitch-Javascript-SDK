
//Configuration
import { Config } from "./config";

//API
import Auth  from "./api/Auth";
import AccessKeys from "./api/AccessKeys"
import Competitions  from "./api/Competitions";
import {Communities, Social} from "./api";
import { Ads } from "./api";
import { Users } from "./api";
import { Events } from "./api";
import { Teams } from "./api";
import { Posts } from "./api";
import {Templates} from "./api";
import { Waitlists } from "./api";
import { Utility } from "./api";
import { Tips } from "./api";
import { TipPackages } from "./api";
import { TipEmojis } from "./api";
import { TipPackagePurchases } from "./api";
import { SocialPosts } from "./api";
import {Titles} from "./api";
import {Campaigns} from "./api";
import {Subscriptions} from "./api";
import {Messages} from "./api";
import {Feedback} from "./api";
import {Influencers} from "./api";
import {Games} from "./api";
import {Publications} from "./api";
import {GameShows} from "./api";
import FestivalNetworking from './api/FestivalNetworking';
export * from './api/FestivalNetworking';
import {Newsletters} from "./api";
import {PlayTests} from "./api";
import {Media} from "./api";
import {Scheduler} from "./api";
import {RedditSubreddits} from "./api";
import {Funnel} from "./api";
import {SocialStats} from "./api";
import {Hashtags} from "./api";
import {WebsiteAnalytics} from "./api";
import {Fingerprinting} from "./api";
import {ShortLinks} from "./api";
import {AIUsage} from "./api";
import {MarketingAgencies} from "./api"
import {TwitchReporting} from './api'
import {Raffles} from './api'
import {DiscordMarketplace} from './api';
import {Education} from './api';
import {Crm} from './api';
import {Multiplayer} from './api';
import {ServerOperations} from './api';
import {Agents} from './api';
import {Mcp} from './api';
import {PrDirectory} from './api';
import {AdminReports} from './api';
import {AdminUsers} from './api';
import {MarketResearch} from './api';
import {GameAdvertising} from './api';
import {Hosting} from './api';
import {GameDesign} from './api';
import {Microtransactions} from './api';
export * from './api/Microtransactions';
export * from './util/MicrotransactionBridge';
export * from './util/MicrotransactionOverlay';

import Requests from "./util/Requests";
import Parser from "./util/Parser";
import Session from "./util/Session";
import Storage from "./util/Storage";
import Data from './util/Data';
import LabelManager from "./util/LabelManager";

import { AcceptanceStatus } from "./constants/AcceptanceStatus";
import AddressLocationType  from "./constants/AddressLocationType";
import CampaignObjective from "./constants/CampaignObjective";
import { ContentStatus } from "./constants/ContentStatus";
import { CompetitionTypes } from "./constants/CompetitionTypes";
import InfluencerCampaignType from "./constants/InfluencerCampaignType";
import { Modes } from "./constants/Modes";
import { PostTypes } from "./constants/PostTypes";
import { Roles } from "./constants/Roles";
import { TeamJoinProcess } from "./constants/TeamJoinProcess";
import {SocialInteractions} from "./constants/SocialInteractions"
import TicketTypes from "./constants/TicketTypes";
import { TicketUsageTypes } from "./constants/TicketUsageTypes";
import { TicketVisibility } from "./constants/TicketVisbility";
import { VenueType } from "./constants/VenueTypes";

class Glitch {

    public static config =  {
        Config: Config
    };

    public static api = {
        Ads: Ads,
        AccessKeys : AccessKeys,
        Auth: Auth,
        Campaigns : Campaigns,
        Competitions: Competitions,
        Communities : Communities,
        Users: Users,
        Events: Events,
        Games : Games,
        GameShows : GameShows,
        Hashtags: Hashtags,
        Feedback : Feedback,
        Influencers : Influencers,
        Teams: Teams,
        Posts: Posts,
        Messages : Messages,
        Templates : Templates,
        Waitlists: Waitlists,
        Utility : Utility,
        Tips: Tips,
        Titles : Titles,
        Social : Social,
        SocialPosts : SocialPosts,
        Subscriptions : Subscriptions,
        TipPackages : TipPackages,
        TipEmojis : TipEmojis ,
        TipPackagePurchases: TipPackagePurchases,
        Publications : Publications,
        Newsletters : Newsletters,
        PlayTests : PlayTests,
        Media : Media,
        FestivalNetworking: FestivalNetworking,
        Scheduler : Scheduler,
        RedditSubreddits : RedditSubreddits,
        Funnel: Funnel,
        SocialStats : SocialStats,
        WebsiteAnalytics: WebsiteAnalytics,
        Fingerprinting : Fingerprinting,
        ShortLinks : ShortLinks,
        AIUsage : AIUsage,
        MarketingAgencies : MarketingAgencies,
        TwitchReporting: TwitchReporting,
        Raffles : Raffles,
        DiscordMarketplace : DiscordMarketplace,
        Education: Education,
        Crm : Crm,
        Multiplayer : Multiplayer,
        ServerOperations : ServerOperations,
        Agents : Agents,
        Mcp : Mcp,
        PrDirectory : PrDirectory,
        AdminReports : AdminReports,
        AdminUsers : AdminUsers,
        MarketResearch : MarketResearch,
        GameAdvertising: GameAdvertising,
        Hosting: Hosting,
        GameDesign: GameDesign,
        Microtransactions: Microtransactions,
    }

    public static util = {
        Requests : Requests,
        Parser : Parser,
        Session: Session,
        Storage : Storage,
        Data : Data,
        LabelManager : LabelManager,
    }

    public static constants = {
       AcceptanceStatus : AcceptanceStatus,
       AddressLocationType : AddressLocationType,
       CampaignObjective :CampaignObjective,
       CompetitionTypes : CompetitionTypes,
       ContentStatus : ContentStatus,
       InfluencerCampaignType : InfluencerCampaignType,
       Modes : Modes,
       PostTypes : PostTypes,
       Roles: Roles,
       SocialInteractions : SocialInteractions,
       TeamJoinProcess : TeamJoinProcess,
       TicketTypes : TicketTypes,
       TicketUsageTypes : TicketUsageTypes,
       TicketVisibility : TicketVisibility,
       VenueType : VenueType
    }


}

export default Glitch;
