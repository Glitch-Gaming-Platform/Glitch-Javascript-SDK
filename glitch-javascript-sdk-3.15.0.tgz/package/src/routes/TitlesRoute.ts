import Route from "./interface";
import HTTP_METHODS from "../constants/HttpMethods";

class TitlesRoute {

  public static routes: { [key: string]: Route } = {
    list: { url: '/titles', method: HTTP_METHODS.GET },
    create: { url: '/titles', method: HTTP_METHODS.POST },
    view: { url: '/titles/{title_id}', method: HTTP_METHODS.GET },
    update: { url: '/titles/{title_id}', method: HTTP_METHODS.PUT },
    delete: { url: '/titles/{title_id}', method: HTTP_METHODS.DELETE },
    approve: { url: '/titles/{title_id}/approve', method: HTTP_METHODS.POST },
    reject: { url: '/titles/{title_id}/reject', method: HTTP_METHODS.POST },
    uploadMainImage: { url: '/titles/{title_id}/uploadMainImage', method: HTTP_METHODS.POST },
    uploadBannerImage: { url: '/titles/{title_id}/uploadBannerImage', method: HTTP_METHODS.POST },
    addAdministrator: { url: '/titles/{title_id}/addAdministrator', method: HTTP_METHODS.POST },
    removeAdministrator: { url: '/titles/{title_id}/removeAdministrator/{user_id}', method: HTTP_METHODS.DELETE },
    addMedia: { url: '/titles/{title_id}/addMedia', method: HTTP_METHODS.POST },
    removeMedia: { url: '/titles/{title_id}/removeMedia/{media_id}', method: HTTP_METHODS.DELETE },
    updateMediaOrder: { url: '/titles/{title_id}/updateMediaOrder', method: HTTP_METHODS.POST },
    importWishlist: { url: '/titles/{title_id}/wishlist/import', method: HTTP_METHODS.POST },
    getWishlist: { url: '/titles/{title_id}/wishlist', method: HTTP_METHODS.GET },
    createToken: { url: '/titles/{title_id}/tokens', method: HTTP_METHODS.POST },
    listTokens: { url: '/titles/{title_id}/tokens', method: HTTP_METHODS.GET },
    revokeToken: { url: '/titles/{title_id}/tokens/{token_id}', method: HTTP_METHODS.DELETE },
    search: { url: '/titles/search', method: HTTP_METHODS.GET },
    listInstalls: { url: '/titles/{title_id}/installs', method: HTTP_METHODS.GET },
    viewInstall: { url: '/titles/{title_id}/installs/{install_id}', method: HTTP_METHODS.GET },
    createInstall: { url: '/titles/{title_id}/installs', method: HTTP_METHODS.POST },
    listRetentions: { url: '/titles/{title_id}/retentions', method: HTTP_METHODS.GET },
    retentionSummary: { url: '/titles/{title_id}/retentions/summary', method: HTTP_METHODS.GET },
    activeRetentions: { url: '/titles/{title_id}/retentions/active', method: HTTP_METHODS.GET },
    retentionAnalysis: { url: '/titles/{title_id}/retentions/analysis', method: HTTP_METHODS.GET },
    distinctDimensions: { url: '/titles/{title_id}/installs/distinctDimensions', method: HTTP_METHODS.GET },
    updateAdministrator: { url: '/titles/{title_id}/updateAdministrator/{user_id}', method: HTTP_METHODS.PUT },
    listSessions: {
      url: '/titles/{title_id}/installs/sessions',
      method: HTTP_METHODS.GET
    },
    sessionsAverage: {
      url: '/titles/{title_id}/installs/sessions/average',
      method: HTTP_METHODS.GET
    },
    sessionsHistogram: {
      url: '/titles/{title_id}/sessions/histogram',
      method: HTTP_METHODS.GET
    },
    /**
     * 1) Import a CSV/Excel file containing daily UTM analytics data for a Title
     *    POST /titles/{title_id}/utm/import
     */
    importUtmAnalytics: {
      url: "/titles/{title_id}/utm/import",
      method: HTTP_METHODS.POST,
    },

    /**
     * 2) Retrieve paginated/filterable UTM analytics data for a Title
     *    GET /titles/{title_id}/utm
     */
    getUtmAnalytics: {
      url: "/titles/{title_id}/utm",
      method: HTTP_METHODS.GET,
    },

    getWebTrackingToken: {
      url: "/titles/{title_id}/webTrackingToken",
      method: HTTP_METHODS.GET,
    },

    /**
     * 3) Analyze UTM data with optional group_by / dimension-based aggregates
     *    GET /titles/{title_id}/utm/analysis
     */
    analyzeUtmAnalytics: {
      url: "/titles/{title_id}/utm/analysis",
      method: HTTP_METHODS.GET,
    },

    chatListSessions: {
      url: '/titles/{title_id}/chat/sessions',
      method: HTTP_METHODS.GET
    },
    chatShowSession: {
      url: '/titles/{title_id}/chat/sessions/{session_id}',
      method: HTTP_METHODS.GET
    },
    chatListMessages: {
      url: '/titles/{title_id}/chat/messages',
      method: HTTP_METHODS.GET
    },
    chatUpdateMessage: {
      url: '/titles/{title_id}/chat/messages/{message_id}',
      method: HTTP_METHODS.PUT
    },

    importKeys: { url: '/titles/{title_id}/import-keys', method: HTTP_METHODS.POST },


    // ─────────────────────────────────────────────────────────────────
    // Purchase/Revenue Endpoints
    // ─────────────────────────────────────────────────────────────────
    purchasesList: {
      url: "/titles/{title_id}/purchases",
      method: HTTP_METHODS.GET,
    },
    purchasesShow: {
      url: "/titles/{title_id}/purchases/{purchase_id}",
      method: HTTP_METHODS.GET,
    },
    purchasesCreate: {
      url: "/titles/{title_id}/purchases",
      method: HTTP_METHODS.POST,
    },
    purchasesSummary: {
      url: "/titles/{title_id}/purchases/summary",
      method: HTTP_METHODS.GET,
    },

    // Advanced analytics sub-routes
    purchasesTimeReport: {
      url: "/titles/{title_id}/purchases/reports/time",
      method: HTTP_METHODS.GET,
    },
    purchasesLtv30Report: {
      url: "/titles/{title_id}/purchases/reports/ltv30",
      method: HTTP_METHODS.GET,
    },
    purchasesCurrencyBreakdown: {
      url: "/titles/{title_id}/purchases/reports/currency",
      method: HTTP_METHODS.GET,
    },
    purchasesInstallDistribution: {
      url: "/titles/{title_id}/purchases/reports/install-distribution",
      method: HTTP_METHODS.GET,
    },
    purchasesItemTypeStats: {
      url: "/titles/{title_id}/purchases/reports/item-type-stats",
      method: HTTP_METHODS.GET,
    },

    listAdConversionEvents: {
      url: '/titles/{title_id}/ad-conversion-events',
      method: HTTP_METHODS.GET
    },
    retryAdConversionEvent: {
      url: '/titles/{title_id}/ad-conversion-events/{event_id}/retry',
      method: HTTP_METHODS.POST
    },

    getAdConversionEventsReport: {
      url: '/titles/{title_id}/ad-conversion-events/report',
      method: HTTP_METHODS.GET
    },

    listLandingPages: { url: '/titles/{title_id}/landing-pages', method: HTTP_METHODS.GET },
    createLandingPage: { url: '/titles/{title_id}/landing-pages', method: HTTP_METHODS.POST },
    viewLandingPage: { url: '/landing-pages/{landing_page_id}', method: HTTP_METHODS.GET },
    updateLandingPage: { url: '/landing-pages/{landing_page_id}', method: HTTP_METHODS.PUT },
    deleteLandingPage: { url: '/landing-pages/{landing_page_id}', method: HTTP_METHODS.DELETE },
    translateLandingPage: { url: '/landing-pages/{landing_page_id}/translate', method: HTTP_METHODS.POST },

    generateLandingPageAiContent: { url: '/landing-pages/{landing_page_id}/generate-ai-content', method: HTTP_METHODS.POST },
    saveLandingPageTranslation: { url: '/landing-pages/{landing_page_id}/translations', method: HTTP_METHODS.POST },

    cohorts: { url: '/titles/{title_id}/installs/cohorts', method: HTTP_METHODS.GET },

    geoReport: { url: '/titles/{title_id}/installs/geo-report', method: HTTP_METHODS.GET },

    // Game Events (Behavioral Telemetry)
    listEvents: { url: '/titles/{title_id}/events', method: HTTP_METHODS.GET },
    createEvent: { url: '/titles/{title_id}/events', method: HTTP_METHODS.POST },
    bulkCreateEvents: { url: '/titles/{title_id}/events/bulk', method: HTTP_METHODS.POST },
    eventSummary: { url: '/titles/{title_id}/events/summary', method: HTTP_METHODS.GET },
    eventDistinctKeys: { url: '/titles/{title_id}/events/distinct-keys', method: HTTP_METHODS.GET },

    // Behavioral Funnels
    listBehavioralFunnels: { url: '/titles/{title_id}/behavioral-funnels', method: HTTP_METHODS.GET },
    createBehavioralFunnel: { url: '/titles/{title_id}/behavioral-funnels', method: HTTP_METHODS.POST },
    behavioralFunnelReport: { url: '/titles/{title_id}/behavioral-funnels/{funnel_id}/report', method: HTTP_METHODS.GET },
    deleteBehavioralFunnel: { url: '/titles/{title_id}/behavioral-funnels/{funnel_id}', method: HTTP_METHODS.DELETE },

    // Aegis Deployment
    getDeploymentUploadUrl: { url: '/titles/{title_id}/deployments/presigned-url', method: HTTP_METHODS.POST },
    confirmDeployment: { url: '/titles/{title_id}/deployments/confirm', method: HTTP_METHODS.POST },
    getPlaySession: { url: '/titles/{title_id}/play', method: HTTP_METHODS.POST },

    initiateMultipartUpload: { url: '/titles/{title_id}/deployments/multipart/initiate', method: HTTP_METHODS.POST },
    getMultipartUrls: { url: '/titles/{title_id}/deployments/multipart/urls', method: HTTP_METHODS.POST },
    completeMultipartUpload: { url: '/titles/{title_id}/deployments/multipart/complete', method: HTTP_METHODS.POST },

    // Aegis Payouts
    listDeveloperPayouts: { url: '/titles/{title_id}/payouts', method: HTTP_METHODS.GET },
    viewDeveloperPayout: { url: '/titles/{title_id}/payouts/{payout_id}', method: HTTP_METHODS.GET },
    developerPayoutSummary: { url: '/titles/{title_id}/payouts/summary', method: HTTP_METHODS.GET },

    /**
    * The Aegis Handshake: Validates if a specific install/session is authorized to play.
    * POST /titles/{title_id}/installs/{install_id}/validate
    */
    validateInstall: {
      url: '/titles/{title_id}/installs/{install_id}/validate',
      method: HTTP_METHODS.POST
    },

    listBuilds: { url: '/titles/{title_id}/deployments', method: HTTP_METHODS.GET },

    listSaves: { url: '/titles/{title_id}/installs/{install_id}/saves', method: HTTP_METHODS.GET },
    storeSave: { url: '/titles/{title_id}/installs/{install_id}/saves', method: HTTP_METHODS.POST },
    resolveSaveConflict: { url: '/titles/{title_id}/installs/{install_id}/saves/{save_id}/resolve', method: HTTP_METHODS.POST },

    wishlistToggle: {
      url: '/titles/{title_id}/wishlist',
      method: HTTP_METHODS.POST
    },
    wishlistUpdateScore: {
      url: '/titles/{title_id}/wishlist/score',
      method: HTTP_METHODS.POST
    },
    wishlistStats: {
      url: '/titles/{title_id}/wishlist/stats',
      method: HTTP_METHODS.GET
    },
    myWishlists: {
      url: '/users/me/wishlists',
      method: HTTP_METHODS.GET
    },
    lookupMyWishlists: {
      url: '/users/me/wishlists/lookup',
      method: HTTP_METHODS.POST
    },

    wishlistMe: {
      url: '/titles/{title_id}/wishlist/me',
      method: HTTP_METHODS.GET
    },
    attributionFunnel: {
      url: '/titles/{title_id}/reports/attribution-funnel',
      method: HTTP_METHODS.GET
    },

    updateBuildStatus: { url: '/titles/{title_id}/deployments/{build_id}/status', method: HTTP_METHODS.PUT },

    // Inside the routes object in TitlesRoute.ts
    getMatchmakerServer: {
      url: '/titles/{title_id}/matchmaker/server',
      method: HTTP_METHODS.GET
    },

    matchmakerSessionHeartbeat: {
      url: '/titles/{title_id}/matchmaker/session/heartbeat',
      method: HTTP_METHODS.POST
    },
    matchmakerSessionRelease: {
      url: '/titles/{title_id}/matchmaker/session/release',
      method: HTTP_METHODS.POST
    },

    getTechnicalEventSummary: {
      url: '/titles/{title_id}/analytics/events-summary',
      method: HTTP_METHODS.GET
    },


    // --- Title Progression Definitions (Developer API) ---
    progressionStatsList: { url: '/titles/{title_id}/progression/stats', method: HTTP_METHODS.GET },
    progressionStatsStore: { url: '/titles/{title_id}/progression/stats', method: HTTP_METHODS.POST },
    progressionStatsDelete: { url: '/titles/{title_id}/progression/stats/{id}', method: HTTP_METHODS.DELETE },

    progressionAchievementsList: { url: '/titles/{title_id}/progression/achievements', method: HTTP_METHODS.GET },
    progressionAchievementsStore: { url: '/titles/{title_id}/progression/achievements', method: HTTP_METHODS.POST },

    progressionLeaderboardsList: { url: '/titles/{title_id}/progression/leaderboards', method: HTTP_METHODS.GET },
    progressionLeaderboardsStore: { url: '/titles/{title_id}/progression/leaderboards', method: HTTP_METHODS.POST },

    progressionSeasonsList: { url: '/titles/{title_id}/progression/seasons', method: HTTP_METHODS.GET },
    progressionSeasonsStore: { url: '/titles/{title_id}/progression/seasons', method: HTTP_METHODS.POST },

    // --- In-Game Progression (Client API) ---
    progressionSubmit: { url: '/titles/{title_id}/installs/{install_id}/submit', method: HTTP_METHODS.POST },
    progressionPlayerStats: { url: '/titles/{title_id}/installs/{install_id}/stats', method: HTTP_METHODS.GET },
    progressionPlayerAchievements: { url: '/titles/{title_id}/installs/{install_id}/achievements', method: HTTP_METHODS.GET },
    progressionLeaderboardView: { url: '/titles/{title_id}/leaderboards/{api_key}', method: HTTP_METHODS.GET },

    communityActivity: { url: '/titles/activity/trending', method: HTTP_METHODS.GET },
    socialTrending: { url: '/titles/activity/social', method: HTTP_METHODS.GET },
    discoveryQueue: { url: '/titles/discovery/queue', method: HTTP_METHODS.GET },

     /**
     * Curated, playable feed for the Swipe interface.
     * GET /titles/discovery/swipe
     */
    swipeFeed: { url: '/titles/discovery/swipe', method: HTTP_METHODS.GET },

    developerPayoutConsolidatedSummary: {
      url: '/titles/{title_id}/payouts/consolidated-summary',
      method: HTTP_METHODS.GET
    },

    wishlistHistory: { url: '/titles/{title_id}/wishlist/history', method: HTTP_METHODS.GET },
    wishlistInfluencers: { url: '/titles/{title_id}/wishlist/influencers', method: HTTP_METHODS.GET },
    wishlistAds: { url: '/titles/{title_id}/wishlist/ads', method: HTTP_METHODS.GET },
    wishlistUtms: { url: '/titles/{title_id}/wishlist/utms', method: HTTP_METHODS.GET },
    wishlistConversions: { url: '/titles/{title_id}/wishlist/conversions', method: HTTP_METHODS.GET },
    wishlistGeo: { url: '/titles/{title_id}/wishlist/geo', method: HTTP_METHODS.GET },
    wishlistDevices: { url: '/titles/{title_id}/wishlist/devices', method: HTTP_METHODS.GET },

    // Game Reviews
    reviewsList: { url: '/titles/{title_id}/reviews', method: HTTP_METHODS.GET },
    reviewsSummary: { url: '/titles/{title_id}/review-summary', method: HTTP_METHODS.GET },
    reviewsCreate: { url: '/titles/{title_id}/reviews', method: HTTP_METHODS.POST },
    reviewsShow: { url: '/reviews/{review_id}', method: HTTP_METHODS.GET },
    reviewsUpdate: { url: '/reviews/{review_id}', method: HTTP_METHODS.PATCH },
    reviewsDelete: { url: '/reviews/{review_id}', method: HTTP_METHODS.DELETE },
    reviewsVote: { url: '/reviews/{review_id}/vote', method: HTTP_METHODS.POST },
    reviewsReport: { url: '/reviews/{review_id}/report', method: HTTP_METHODS.POST },
    reviewsDeveloperResponse: { url: '/reviews/{review_id}/developer-response', method: HTTP_METHODS.POST },

  };

}

export default TitlesRoute;
