# Game microtransactions

The SDK entry point is `Glitch.api.Microtransactions`. All HTTP methods return an
Axios response whose `response.data.data` contains the typed commerce result.
Configure the ordinary API base once using the existing Glitch configuration.
Never put a developer/MCP/install token into a shipped browser game.

## Developer setup

1. Read `settings`, `readiness`, `providers` and `listProducts` with a signed-in
   title administrator. Start disabled/sandbox. Approvals are server-controlled.
2. `uploadMedia(titleId, file, onProgress?)` reuses existing Glitch Media with
   trusted title/actor ownership. Attach returned `id` to `media_ids` or
   `branding.logo_media_id`. No scheduler or social-library post is created.
3. Create a product draft using `createProduct`. Prices use integer minor units,
   not floating-point money: USD 499 means $4.99; JPY 499 means ¥499. Supported
   currencies are USD/EUR/GBP/CAD/AUD/JPY/BRL/INR/KRW; provider coverage can be
   narrower. Each price is 1–100000 minor units, with country `US` or `*` fallback.
   Provider-specific purchase minima are checked separately (sandbox USD: 50).
4. Product types are durable, consumable, currency, bundle or pass. Grants have
   a stable key, quantity and kind. Durable quantity is one. Pass requires
   `duration_seconds` between 60 and 31536000, with no active stacking. Existing
   purchased grants cannot be changed in place: create a new SKU. No recurring
   subscriptions, gifts, paid random loot, cash-out or cross-game wallet support.
5. Configure the exact game origin, regions/currencies, support contact and
   game name/accent/logo with `updateSettings`. The fixed commission is 1200bp
   (12%) of discounted pre-tax subtotal. Actual provider costs are separate.
   Taxes are separate; pending earnings are not a verified available payout.
6. Run a real approved provider sandbox purchase, verify game delivery/claim,
   then call `verifyIntegration(titleId, {order_id, confirm:true})`. This records
   real evidence, not a self-certified integration checkbox. Launch still needs
   independent seller/tax/provider approvals. MCP confirm alone cannot supply them.

Product limits: SKU/grant key 1–100 alphanumeric/underscore/dot/hyphen characters;
name 255 characters; description 4000; 10 distinct Media UUIDs; 50 prices; 30
distinct grants; 30 localizations. Settings allow 20 exact origins (255 chars
each), 100 countries and 20 supported currencies. Branding name maximum 100.
Server capability schemas remain authoritative.

## Hosted checkout and account creation

`createCheckoutSession(titleId, {product_id,quantity,country,currency,environment,
channel:'web',return_origin,nonce})` is anonymous-safe and only opens the purchase
flow. Use `createMicrotransactionNonce()` to generate the nonce and retain it in
the game. `hosted_url` points to Glitch's game-branded checkout with the session
secret in a `#token` fragment, never a query parameter.

Use `openMicrotransactionOverlay` to mount an accessible modal iframe inside the
running game, even if the game is itself embedded. The game document, URL,
session, canvas and state remain intact. Do not navigate the game away for checkout
or provide a top-level fallback. The iframe permits payments and controlled
bank/OAuth verification windows but has no top-navigation sandbox permission.
When embedding or required verification is unavailable, offer retry/close while
preserving the game. Retry reloads only the same session, not a new charge.

The overlay bounds each document-loading and application-ready wait to 20 seconds
by default (`frameLoadTimeoutMs`, clamped to 1–60 seconds). A missing iframe load
or error event cannot leave the player indefinitely at Loading. Timeout displays
explicit Retry/Close guidance without initiating payment or navigating the game.
A document `load` only starts the bounded application-ready wait; it is not proof
that checkout rendered. The hosted page sends
`{type:'glitch.microtransaction.ready',version:1,title_id,checkout_session_id,nonce}`
only after its valid-session account/checkout UI is usable. Exact origin/source/
session/nonce checks protect this signal, and it never grants inventory. Retry
resets timers; verified readiness and close clear them.

The read-only `getCheckoutFramePolicy(titleId,sessionId)` returns only approved
`frame_ancestors` and expiry; the hosted document uses that server-owned policy.
It does not expose a checkout token or player data.

Inside Glitch, the page uses existing sign-in/registration/OAuth and binds the
checkout session once to that user. Session methods require
`{checkoutToken: sessionSecret}` as their last options argument. The existing
signed-in account JWT stays inside Glitch, not the game. The SDK sends the limited
session secret only in `X-Checkout-Token` and never temporarily changes global auth.

`checkout(titleId, sessionId, {idempotency_key,accept_terms:true}, options)` returns
an order, quote, provider and UI mode. Stripe uses `ui_mode:'embedded'`, a limited
`client_secret` and public `publishable_key`; mount Stripe Embedded Checkout
inside the branded page, never build custom raw card fields. Approved Xsolla
routes use `ui_mode:'xsolla'` and its official Pay Station flow. Disclose payment
methods that need external authentication.

Stripe 3DS is part of checkout. Exercise challenge success, cancel/failure,
timeout and reload in the real sandbox. Keep the same order/session/idempotency
key through authentication. `action_required`, provider authorization, redirect,
and client completion are not paid/delivered proof. Call
`reconcileCheckoutSession(titleId, sessionId, options)` to query the original
attempt; never charge another provider after an uncertain submission.

## Verified game/account handoff

After verified payment and fulfillment, `createHandoff` returns an event with
`type:'glitch.microtransaction.updated'`, `version:1`, `title_id`,
`checkout_session_id`, `order_id`, `nonce`, and a one-time `claim_code` valid for
two minutes. The hosted page targets the exact approved game origin. It never
posts the account JWT or a player token.

The game must compare exact origin, actual checkout iframe window, title, session
and nonce before exchanging the code. The overlay performs these checks and
redeems the code, then refreshes authoritative inventory using per-request scoped
credentials. This is the preferred integration:

```ts
import Glitch, {
  createMicrotransactionNonce,
  openMicrotransactionOverlay,
  openMicrotransactionRestoreOverlay,
} from 'glitch-javascript-sdk';

const session = (await Glitch.api.Microtransactions.createCheckoutSession(titleId, {
  product_id: productId,
  quantity: 1,
  country: 'US',
  currency: 'USD',
  environment: 'sandbox',
  channel: 'web',
  return_origin: window.location.origin,
  nonce: createMicrotransactionNonce(),
})).data.data;

const overlay = openMicrotransactionOverlay({
  titleId,
  checkoutOrigin: trustedGlitchOrigin, // fixed by the integration, not message data
  session,
  onOpen: () => pauseGameInput(),
  onClose: () => resumeGameInput(),
  onVerified: result => replaceDisplayedInventory(result.entitlements),
  onOrderUpdate: order => showReceiptStatus(order), // NOT permission to grant goods
  onError: () => showPurchaseRecovery(),
});
// await overlay.close() removes only checkout and restores focus.
```

This example's game functions/identifiers are integration placeholders, not SDK
APIs. The verified result is the actual claim DTO. The helper validates matching
title/session/order and, on refresh, the same player. It ignores duplicate codes
even after a network timeout because the server may already have consumed them.
It does not grant items from window data or continuously poll. A close message
uses `{type:'glitch.microtransaction.close',version:1,title_id,
checkout_session_id,nonce}` and must match the same exact origin/source/session.
The dialog remains mounted until an in-flight claim and inventory callback finish.
Close before a successful claim can refresh limited receipt status only; show
pending/restore guidance, never claim that a checkout capability grants inventory.

`player_token` lasts 15 minutes and is restricted to one title/player/environment.
Keep it in memory and pass `{playerToken}` per request to `getOrder`,
`listEntitlements` and `consume`. Never install it in global `Glitch.util.Session`
or `Requests.setAuthToken`, log it, or put it in URLs. The SDK's per-request
headers prevent simultaneous account/checkout requests from overwriting auth.

After expiry/reload or a lost claim response, call the anonymous-safe
`createRestoreSession(titleId,{return_origin,nonce,environment})` and pass its
returned `intent:'restore'` session to `openMicrotransactionRestoreOverlay` with
the same hooks shown above. The account signs in inside the modal, then Glitch
selects an owned paid purchase and sends its verified handoff. No original receipt
ID or account JWT is required from the game, and restore never calls `/checkout`.
The new session ID is known before authentication and remains strictly pinned.
Restoring cannot duplicate ownership or recreate spent consumables; fully refunded,
unpaid or failed purchases cannot issue a paid handoff.

Lower-level `createMicrotransactionBridge` remains available for existing in-game
iframe implementations; pass the actual iframe's `contentWindow`. Its `refresh()`
works only after a successful claim. The older JWT-only `restoreHandoff` and
receipt-pinned `createMicrotransactionRestoreBridge` are specialized trusted
hosted-account flows, not the default anonymous-game recovery path.

## Gameplay, refunds and failures

- Use server entitlements, not mutable cloud saves. `consume` atomically spends
  consumable units with a unique gameplay `action_id`; reuse that ID for retries.
  Free local gameplay cannot mint paid balances. Pass expiry is server-authoritative.
- Keep payment, fulfillment and settlement independent. Paid can coexist with
  pending server delivery. Replaying delivery reuses immutable IDs and never
  grants twice. Provider and game messages are at-least-once delivery.
- Earnings `transferred_minor` means money transferred to a provider balance,
  not a confirmed bank deposit. Preserve `bank_payout_status` and reserve/reconciliation
  fields; never relabel pending or transferred balances as paid bank payouts.
- `requestRefund` is an owning account's support request. `refundOrder` requires
  a separately approved financial administrator; pending/unknown is not completed.
  Preserve historical orders and reverse commission proportionately. Refunds
  use the original provider/account, not the currently preferred payment route.
- Handle HTTP 401/403 for account/scope, 404 for unavailable or cross-title IDs,
  409 for idempotency/state/approval conflicts, 410 for expired sessions/claims,
  422 for invalid inputs/revenue policy, 429 for rate limits and 503 for provider
  coverage. Do not retry a hard decline/fraud block through another provider.
- Ads-off is an actual per-title delivery policy. The backend rejects removing
  the final working revenue model. Provider outages leave ads off and existing
  ownership intact. Sandbox products do not constitute production monetization.

## MCP

Use `mcpCapabilities` to discover exact schemas, abilities, approval flags and
examples. `mcpOperation` always targets the authenticated MCP facade; it never
uses a game's runtime token. `mcpUploadMedia` uses the same authorized Media
pipeline. The companion `glitch-mcp` package supplies explicit tools, a
`glitch://microtransactions/setup` resource, dynamic title schema resources and
the `glitch_setup_microtransactions` prompt. A model must not auto-approve live
prices, provider activation, financial actions or disabling the last revenue model.
